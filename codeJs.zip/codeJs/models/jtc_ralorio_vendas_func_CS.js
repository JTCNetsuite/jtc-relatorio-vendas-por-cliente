/**
 * @NAPIVersion 2.x
 * @NModuleScope public
 */
define(["require", "exports", "N/search", "../module/jtc_relatorio_vendas_CTS"], function (require, exports, search, jtc_relatorio_vendas_CTS_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.fieldChanged = void 0;
    var fieldChanged = function (ctx) {
        if (ctx.fieldId == jtc_relatorio_vendas_CTS_1.constant.FORM.FILTERS.PARTNER.ID) {
            var parter = ctx.currentRecord.getValue(jtc_relatorio_vendas_CTS_1.constant.FORM.FILTERS.PARTNER.ID);
            var searchParter = search.create({
                type: search.Type.PARTNER,
                filters: ["internalid", search.Operator.ANYOF, parter],
                columns: [
                    search.createColumn({ name: jtc_relatorio_vendas_CTS_1.constant.PARTNER.EMAIL })
                ]
            }).run().getRange({ start: 0, end: 1 });
            if (searchParter.length > 0) {
                var email = searchParter[0].getValue({ name: jtc_relatorio_vendas_CTS_1.constant.PARTNER.EMAIL });
                ctx.currentRecord.setValue({ fieldId: jtc_relatorio_vendas_CTS_1.constant.FORM.FILTERS.EMAIL.ID, value: "".concat(email, ";") });
            }
        }
    };
    exports.fieldChanged = fieldChanged;
});
