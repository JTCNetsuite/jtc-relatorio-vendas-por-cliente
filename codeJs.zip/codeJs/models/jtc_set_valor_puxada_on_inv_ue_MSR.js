/**
 * @NAPIVersion 2.x
 * @NModuleScope public
 */
define(["require", "exports", "N/log", "N/record", "../module/jtc_relatorio_vendas_CTS"], function (require, exports, log, record, jtc_relatorio_vendas_CTS_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeSubmit = void 0;
    var beforeSubmit = function (ctx) {
        try {
            var curr = ctx.newRecord;
            var idSalesOrder = curr.getValue(jtc_relatorio_vendas_CTS_1.constant.INVOICE.CREATEFROM);
            var recSalesOrder = record.load({
                type: record.Type.SALES_ORDER,
                id: idSalesOrder
            });
            var valor_puxada = recSalesOrder.getValue(jtc_relatorio_vendas_CTS_1.constant.SALES_ORDER.PUXADA);
            log.debug("valor_puxada", valor_puxada);
            if (!!valor_puxada) {
                curr.setValue({ fieldId: jtc_relatorio_vendas_CTS_1.constant.INVOICE.PUXADA, value: valor_puxada });
            }
        }
        catch (e) {
            log.error('jtc_set_valor_puxada_on_inv_MSR.beforeSubmit', e);
        }
    };
    exports.beforeSubmit = beforeSubmit;
});
