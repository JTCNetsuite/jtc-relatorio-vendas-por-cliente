/**
 * @NAPIVersion 2.x
 * @NModuleScope public
 */
define(["require", "exports", "N/ui/serverWidget", "N/log", "../module/jtc_relatorio_vendas_CTS", "N/record", "N/search", "N/email", "N/file"], function (require, exports, UI, log, jtc_relatorio_vendas_CTS_1, record, search, email, file) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    var onRequest = function (ctx) {
        try {
            var form = UI.createForm({
                title: jtc_relatorio_vendas_CTS_1.constant.FORM.TITLE
            });
            form.clientScriptModulePath = '../controllers/jtc_relatorio_vendas_cliente_CS.js';
            if (ctx.request.method == "GET") {
                getForm(form, ctx);
            }
            else {
                postForm(form, ctx);
            }
        }
        catch (error) {
            log.error('jtc_relatorio_vendas_MSR.onRequest', error);
        }
    };
    exports.onRequest = onRequest;
    var getForm = function (form, ctx) {
        try {
            var partner = form.addField({
                id: jtc_relatorio_vendas_CTS_1.constant.FORM.FILTERS.PARTNER.ID,
                label: jtc_relatorio_vendas_CTS_1.constant.FORM.FILTERS.PARTNER.LABEL,
                type: UI.FieldType.SELECT,
                source: String(record.Type.PARTNER)
            }).isMandatory = true;
            var checkEnmail = form.addField({
                id: jtc_relatorio_vendas_CTS_1.constant.FORM.FILTERS.ENVIO_EMAIL.ID,
                label: jtc_relatorio_vendas_CTS_1.constant.FORM.FILTERS.ENVIO_EMAIL.label,
                type: UI.FieldType.CHECKBOX
            });
            var emails = form.addField({
                id: jtc_relatorio_vendas_CTS_1.constant.FORM.FILTERS.EMAIL.ID,
                label: jtc_relatorio_vendas_CTS_1.constant.FORM.FILTERS.EMAIL.label,
                type: UI.FieldType.TEXT
            });
            var data_de = form.addField({
                id: jtc_relatorio_vendas_CTS_1.constant.FORM.FILTERS.DATA_DE.ID,
                label: jtc_relatorio_vendas_CTS_1.constant.FORM.FILTERS.DATA_DE.LABEL,
                type: UI.FieldType.DATE
            });
            var data_ate = form.addField({
                id: jtc_relatorio_vendas_CTS_1.constant.FORM.FILTERS.DATE_ATE.ID,
                label: jtc_relatorio_vendas_CTS_1.constant.FORM.FILTERS.DATE_ATE.LABEL,
                type: UI.FieldType.DATE
            });
            form.addSubmitButton({
                label: jtc_relatorio_vendas_CTS_1.constant.FORM.SUBMIT_BTN
            });
            ctx.response.writePage(form);
        }
        catch (error) {
            log.error('jtc_relatorio_vendas_MSR.getForm', error);
        }
    };
    var postForm = function (form, ctx) {
        try {
            log.debug('ctx', ctx.request.parameters);
            var body = ctx.request.parameters;
            var parter = body.custpage_partner;
            var data_de = body.custpage_date_de;
            var data_ate = body.custpage_date_ate;
            var partner_diplay = body.custpage_partner_display;
            var email_check = body.custpage_enviar_email;
            var partner_emails = String(body.custpage_email).split(";");
            var filters = [];
            if (!!parter) {
                filters.push([
                    jtc_relatorio_vendas_CTS_1.constant.INVOICE.PARTNER, search.Operator.ANYOF, parter
                ]);
                filters.push("AND");
            }
            if (!!data_de && !!data_ate) {
                filters.push([
                    jtc_relatorio_vendas_CTS_1.constant.INVOICE.DATA_FATURAMENTO, search.Operator.WITHIN, data_de, data_ate
                ]);
                filters.push("AND");
            }
            else if (!!data_de) {
                filters.push([
                    jtc_relatorio_vendas_CTS_1.constant.INVOICE.DATA_FATURAMENTO, search.Operator.AFTER, data_de
                ]);
                filters.push("AND");
            }
            else if (!!data_ate) {
                filters.push([
                    jtc_relatorio_vendas_CTS_1.constant.INVOICE.DATA_FATURAMENTO, search.Operator.BEFORE, data_ate
                ]);
                filters.push("AND");
            }
            filters.push(["mainline", search.Operator.IS, "T"]);
            log.debug('filters', filters);
            var searchInvoice = search.create({
                type: search.Type.INVOICE,
                filters: filters,
                columns: [
                    search.createColumn({ name: jtc_relatorio_vendas_CTS_1.constant.INVOICE.CREATEFROM }),
                    search.createColumn({ name: jtc_relatorio_vendas_CTS_1.constant.CUSTOMER.NAME, join: jtc_relatorio_vendas_CTS_1.constant.CUSTOMER.ID }),
                    search.createColumn({ name: jtc_relatorio_vendas_CTS_1.constant.INVOICE.NF }),
                    search.createColumn({ name: jtc_relatorio_vendas_CTS_1.constant.INVOICE.DATA_FATURAMENTO }),
                    search.createColumn({ name: jtc_relatorio_vendas_CTS_1.constant.INVOICE.TOTAL }),
                    search.createColumn({ name: jtc_relatorio_vendas_CTS_1.constant.PARTNER.COMISSAO, join: jtc_relatorio_vendas_CTS_1.constant.PARTNER.ID }),
                    search.createColumn({ name: jtc_relatorio_vendas_CTS_1.constant.INVOICE.PUXADA })
                ]
            }).run().getRange({ start: 0, end: 1000 });
            log.debug('searchInvoide', searchInvoice.length);
            var page = pageHtml(searchInvoice, partner_diplay, data_de, data_ate);
            if (email_check == "T" || email_check == true) {
                var createFile = file.create({
                    name: 'relatorio.html',
                    fileType: file.Type.HTMLDOC,
                    contents: page,
                    folder: 964,
                    isOnline: true
                }).save();
                var urlfile = file.load({ id: createFile }).url;
                log.audit("filed", createFile);
                var body_1 = "Relat\u00F3rio de vendas <br></br>\n            Peri\u00F3do: de ".concat(data_de, "  at\u00E9 ").concat(data_ate, "<br></br>\n            <br></br>\n            <a href=\"").concat(urlfile, "\">link para o relat\u00F3rio</a>\n            ");
                email.send({
                    author: 192,
                    subject: 'Relatório de Vendas',
                    body: body_1,
                    recipients: partner_emails
                });
            }
            ctx.response.write(page);
        }
        catch (error) {
            log.error('jtc_relatorio_vendas_MSR.postForm', error);
        }
    };
    var pageHtml = function (invoices, partner, data_de, data_ate) {
        var html = "<!DOCTYPE html>\n    <html lang=\"pt-br\">\n    <head>\n        <meta charset=\"UTF-8\">\n        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n        <title>Relat\u00F3rio</title>\n        <style>\n           \n            * {\n                font-family: Arial;\n                // padding: 1px;\n                // margin: 0;\n            }\n            table {\n                width: 100%;\n               \n            }\n            th {\n                font-size: 15px\n            }\n            td {\n                border-bottom: 1px solid black;\n            }\n            \n        </style>\n    </head>\n    <body>\n    <h1>Relat\u00F3rio de Vendas</h1>\n    <p>Vendedor: ".concat(partner, " </p>\n    <p>Per\u00EDodo: de ").concat(data_de, "  at\u00E9 ").concat(data_ate, "</p>\n    <table style=\" border-collapse: collapse;\"> \n    <tr>\n        <th>PEDIDO</th>\n        <th>N.F.</th>\n        <th>CLIENTE</th>\n        <th>D. FAT</th>\n        <th>$ TOTAL</th>\n        <th>% COM</th>\n        <th>$ COMISS\u00C0O</th>\n    </tr>\n    ");
        var total_sum = 0;
        var total_comissao = 0;
        for (var i = 0; i < invoices.length; i++) {
            var valor = Number(invoices[i].getValue({ name: jtc_relatorio_vendas_CTS_1.constant.INVOICE.TOTAL }));
            var saleorderNum = String(invoices[i].getText({ name: jtc_relatorio_vendas_CTS_1.constant.INVOICE.CREATEFROM })).split('#')[1];
            var com;
            com = invoices[i].getValue({ name: jtc_relatorio_vendas_CTS_1.constant.PARTNER.COMISSAO, join: jtc_relatorio_vendas_CTS_1.constant.PARTNER.ID });
            var valor_puxada = Number(invoices[i].getValue({ name: jtc_relatorio_vendas_CTS_1.constant.INVOICE.PUXADA }));
            log.debug("valor", valor_puxada);
            var com_em_porcem = Number(String(com).split("%")[0]) / 100;
            var comissao;
            if (!!valor_puxada) {
                var valor_liq_puxada = valor_puxada * 0.8;
                var valor_total_sem_puxada = valor - valor_puxada;
                var comissao_sem_puxada = valor_total_sem_puxada * com_em_porcem;
                var total_comissao_1 = comissao_sem_puxada + valor_liq_puxada;
                com = Number((total_comissao_1 / valor) * 100).toFixed(2);
                log.debug('com puxada', com);
                comissao = valor * (com / 100);
                com = String(com) + "%";
            }
            else {
                comissao = valor * com_em_porcem;
            }
            // const salesOrderId = invoices[i].getValue({name: CTS.INVOICE.CREATEFROM})
            // const recSalesOrder = record.load({
            //     type: record.Type.SALES_ORDER,
            //     id:salesOrderId
            // })
            // const valor_puxada = recSalesOrder.getValue(CTS.SALES_ORDER.PUXADA)
            // log.debug("valor")
            total_comissao += comissao;
            total_sum += valor;
            html += '<tr>';
            html += "<td><strong>".concat(saleorderNum, "<strong></td>");
            html += "<td>".concat(invoices[i].getValue({ name: jtc_relatorio_vendas_CTS_1.constant.INVOICE.NF }), "</td>");
            html += "<td style=\"font-size: 16px\">".concat(invoices[i].getValue({ name: jtc_relatorio_vendas_CTS_1.constant.CUSTOMER.NAME, join: jtc_relatorio_vendas_CTS_1.constant.CUSTOMER.ID }), "</td>");
            html += "<td>".concat(invoices[i].getValue({ name: jtc_relatorio_vendas_CTS_1.constant.INVOICE.DATA_FATURAMENTO }), "</td>");
            html += "<td style=\"text-align: end;\">".concat(formatarMoeda(valor), "</td>");
            html += "<td style=\"text-align: end;\">".concat(com, "</td>");
            html += "<td style=\"text-align: end;\">".concat(formatarMoeda(comissao), "</td>");
            html += '</tr>';
        }
        html += "<tr>\n        <td colspan=\"4\" style=\"text-align: center;\"><strong>Total<strong></td>\n        <td style=\"text-align: end;\">".concat(formatarMoeda(total_sum), " </td>\n        <td></td>\n        <td style=\"text-align: end;\">").concat(formatarMoeda(total_comissao), "</td>\n        \n    </tr>");
        html += '</table>';
        html += "</body></html>";
        return html;
    };
    var formatarMoeda = function (valor) {
        var partes = valor.toFixed(2).split('.');
        partes[0] = partes[0].replace(/\B(?=(\d{3})+(?!\d))/g, '.');
        return "".concat(partes.join(','));
    };
});
