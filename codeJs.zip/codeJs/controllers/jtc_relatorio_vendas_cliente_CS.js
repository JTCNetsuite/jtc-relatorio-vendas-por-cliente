/**
 * @NAPIVersion 2.x
 * @NScriptType ClientScript
 */
define(["require", "exports", "../models/jtc_ralorio_vendas_func_CS", "N/log"], function (require, exports, MSR, log) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.fieldChanged = void 0;
    var fieldChanged = function (ctx) {
        try {
            MSR.fieldChanged(ctx);
        }
        catch (e) {
            log.error("jtc_relatorio_vendas_cliente_CS.fieldChanged", e);
        }
    };
    exports.fieldChanged = fieldChanged;
});
