/**
 * @NAPIVersion 2.x
 * @NScriptType UserEventScript
 */
define(["require", "exports", "../models/jtc_set_valor_puxada_on_inv_ue_MSR", "N/log"], function (require, exports, MSR, log) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.beforeSubmit = void 0;
    var beforeSubmit = function (ctx) {
        try {
            MSR.beforeSubmit(ctx);
        }
        catch (e) {
            log.error("jtc_set_valor_puxada_UE.beforeSubmit", e);
        }
    };
    exports.beforeSubmit = beforeSubmit;
});
